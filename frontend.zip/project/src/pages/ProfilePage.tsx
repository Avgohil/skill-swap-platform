import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Camera, Edit3, Save, X, Plus, MapPin, Calendar, Star, Award } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const ProfilePage: React.FC = () => {
  const { user, updateProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: user?.name || '',
    location: user?.location || '',
    bio: user?.bio || '',
    availability: user?.availability || []
  });

  if (!user) {
    return <div>Please log in to view your profile.</div>;
  }

  const handleSave = async () => {
    await updateProfile(editForm);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditForm({
      name: user.name,
      location: user.location || '',
      bio: user.bio || '',
      availability: user.availability
    });
    setIsEditing(false);
  };

  const addAvailability = (day: string) => {
    if (!editForm.availability.includes(day)) {
      setEditForm(prev => ({
        ...prev,
        availability: [...prev.availability, day]
      }));
    }
  };

  const removeAvailability = (day: string) => {
    setEditForm(prev => ({
      ...prev,
      availability: prev.availability.filter(d => d !== day)
    }));
  };

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-lg overflow-hidden mb-8"
        >
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 h-32"></div>
          <div className="relative px-6 pb-6">
            {/* Profile Picture */}
            <div className="flex justify-center -mt-16 mb-4">
              <div className="relative">
                <div className="w-32 h-32 bg-white rounded-full p-2 shadow-lg">
                  <div className="w-full h-full bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-3xl font-bold">
                      {user.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                </div>
                <button className="absolute bottom-2 right-2 bg-white rounded-full p-2 shadow-lg hover:bg-gray-50 transition-colors">
                  <Camera className="w-4 h-4 text-gray-600" />
                </button>
              </div>
            </div>

            {/* Profile Info */}
            <div className="text-center">
              {isEditing ? (
                <div className="space-y-4 max-w-md mx-auto">
                  <input
                    type="text"
                    value={editForm.name}
                    onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full text-center text-2xl font-bold border-b-2 border-blue-500 bg-transparent focus:outline-none"
                  />
                  <input
                    type="text"
                    value={editForm.location}
                    onChange={(e) => setEditForm(prev => ({ ...prev, location: e.target.value }))}
                    placeholder="Location"
                    className="w-full text-center text-gray-600 border-b border-gray-300 bg-transparent focus:outline-none focus:border-blue-500"
                  />
                  <textarea
                    value={editForm.bio}
                    onChange={(e) => setEditForm(prev => ({ ...prev, bio: e.target.value }))}
                    placeholder="Tell others about yourself..."
                    className="w-full text-center text-gray-600 border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    rows={3}
                  />
                </div>
              ) : (
                <>
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">{user.name}</h1>
                  {user.location && (
                    <div className="flex items-center justify-center text-gray-600 mb-2">
                      <MapPin className="w-4 h-4 mr-1" />
                      <span>{user.location}</span>
                    </div>
                  )}
                  {user.bio && (
                    <p className="text-gray-600 max-w-md mx-auto mb-4">{user.bio}</p>
                  )}
                </>
              )}

              {/* Stats */}
              <div className="flex justify-center space-x-8 mb-6">
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-1">
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <span className="text-2xl font-bold text-gray-900">{user.rating}</span>
                  </div>
                  <p className="text-sm text-gray-600">Rating</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-1">
                    <Award className="w-5 h-5 text-blue-500" />
                    <span className="text-2xl font-bold text-gray-900">{user.completedSwaps}</span>
                  </div>
                  <p className="text-sm text-gray-600">Swaps</p>
                </div>
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-1">
                    <Calendar className="w-5 h-5 text-green-500" />
                    <span className="text-2xl font-bold text-gray-900">
                      {new Date(user.joinedDate).getFullYear()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">Joined</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex justify-center space-x-4">
                {isEditing ? (
                  <>
                    <button
                      onClick={handleSave}
                      className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save</span>
                    </button>
                    <button
                      onClick={handleCancel}
                      className="flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors"
                    >
                      <X className="w-4 h-4" />
                      <span>Cancel</span>
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Edit3 className="w-4 h-4" />
                    <span>Edit Profile</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Availability Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl shadow-lg p-6 mb-8"
        >
          <h2 className="text-xl font-bold text-gray-900 mb-4">Availability</h2>
          {isEditing ? (
            <div className="space-y-3">
              <p className="text-sm text-gray-600">Select your available days:</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {daysOfWeek.map((day) => (
                  <button
                    key={day}
                    onClick={() => {
                      if (editForm.availability.includes(day)) {
                        removeAvailability(day);
                      } else {
                        addAvailability(day);
                      }
                    }}
                    className={`p-2 rounded-lg text-sm font-medium transition-colors ${
                      editForm.availability.includes(day)
                        ? 'bg-blue-100 text-blue-800 border-2 border-blue-300'
                        : 'bg-gray-100 text-gray-600 border-2 border-transparent hover:bg-gray-200'
                    }`}
                  >
                    {day.substring(0, 3)}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-wrap gap-2">
              {user.availability.length > 0 ? (
                user.availability.map((day) => (
                  <span
                    key={day}
                    className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium"
                  >
                    {day}
                  </span>
                ))
              ) : (
                <p className="text-gray-500">No availability set</p>
              )}
            </div>
          )}
        </motion.div>

        {/* Skills Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Skills Offered */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white rounded-2xl shadow-lg p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-900">Skills I Offer</h2>
              <button className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 transition-colors">
                <Plus className="w-4 h-4" />
                <span className="text-sm">Add</span>
              </button>
            </div>
            
            <div className="space-y-3">
              {user.skillsOffered.length > 0 ? (
                user.skillsOffered.map((skill) => (
                  <div key={skill.id} className="p-3 border border-gray-200 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-medium text-gray-900">{skill.name}</h3>
                        <p className="text-sm text-gray-600 mt-1">{skill.description}</p>
                        <div className="flex items-center space-x-2 mt-2">
                          <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                            {skill.category}
                          </span>
                          <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                            {skill.level}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center py-8">No skills offered yet</p>
              )}
            </div>
          </motion.div>

          {/* Skills Wanted */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white rounded-2xl shadow-lg p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-900">Skills I Want</h2>
              <button className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 transition-colors">
                <Plus className="w-4 h-4" />
                <span className="text-sm">Add</span>
              </button>
            </div>
            
            <div className="space-y-3">
              {user.skillsWanted.length > 0 ? (
                user.skillsWanted.map((skill) => (
                  <div key={skill.id} className="p-3 border border-gray-200 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-medium text-gray-900">{skill.name}</h3>
                        <p className="text-sm text-gray-600 mt-1">{skill.description}</p>
                        <div className="flex items-center space-x-2 mt-2">
                          <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full">
                            {skill.category}
                          </span>
                          <span className="px-2 py-1 bg-orange-100 text-orange-800 text-xs rounded-full">
                            {skill.level}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center py-8">No skills requested yet</p>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};