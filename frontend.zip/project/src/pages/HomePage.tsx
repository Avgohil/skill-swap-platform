import React from 'react';
import { Hero } from '../components/Home/Hero';
import { Features } from '../components/Home/Features';

export const HomePage: React.FC = () => {
  return (
    <div>
      <Hero />
      <Features />
    </div>
  );
};