import React, { useState, useMemo } from 'react';
import { Search, Filter, Grid, List } from 'lucide-react';
import { motion } from 'framer-motion';
import { SkillCard } from '../components/Skills/SkillCard';
import { Skill, User } from '../types';

export const SkillsPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedLevel, setSelectedLevel] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Mock data
  const mockSkills: Array<{ skill: Skill; user: User }> = [
    {
      skill: {
        id: '1',
        name: 'React Development',
        category: 'Programming',
        description: 'Learn modern React development with hooks, context, and best practices. Perfect for building scalable web applications.',
        level: 'Advanced',
        tags: ['react', 'javascript', 'frontend', 'hooks']
      },
      user: {
        id: '1',
        name: 'Priya Sharma',
        email: 'priya@example.com',
        location: 'Bangalore, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.9,
        completedSwaps: 23,
        joinedDate: '2024-01-15'
      }
    },
    {
      skill: {
        id: '2',
        name: 'UI/UX Design',
        category: 'Design',
        description: 'Master the fundamentals of user interface and experience design using Figma and Adobe Creative Suite.',
        level: 'Intermediate',
        tags: ['figma', 'design', 'ux', 'ui']
      },
      user: {
        id: '2',
        name: 'Arjun Patel',
        email: 'arjun@example.com',
        location: 'Mumbai, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.7,
        completedSwaps: 18,
        joinedDate: '2024-02-01'
      }
    },
    {
      skill: {
        id: '3',
        name: 'Hindi Language',
        category: 'Languages',
        description: 'Learn Hindi language from basics to advanced conversation with a native speaker.',
        level: 'Beginner',
        tags: ['hindi', 'conversation', 'language', 'native']
      },
      user: {
        id: '3',
        name: 'Kavya Reddy',
        email: 'kavya@example.com',
        location: 'Hyderabad, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.8,
        completedSwaps: 31,
        joinedDate: '2023-12-10'
      }
    },
    {
      skill: {
        id: '4',
        name: 'Guitar Playing',
        category: 'Music',
        description: 'Learn acoustic guitar from beginner to intermediate level. Covers chords, strumming patterns, and basic music theory.',
        level: 'Beginner',
        tags: ['guitar', 'music', 'acoustic', 'chords']
      },
      user: {
        id: '4',
        name: 'Rohit Gupta',
        email: 'rohit@example.com',
        location: 'Delhi, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.6,
        completedSwaps: 15,
        joinedDate: '2024-03-05'
      }
    },
    {
      skill: {
        id: '5',
        name: 'Data Science with Python',
        category: 'Programming',
        description: 'Comprehensive data science training including pandas, numpy, matplotlib, and machine learning basics.',
        level: 'Advanced',
        tags: ['python', 'data-science', 'machine-learning', 'pandas']
      },
      user: {
        id: '5',
        name: 'Ananya Singh',
        email: 'ananya@example.com',
        location: 'Pune, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.9,
        completedSwaps: 42,
        joinedDate: '2023-11-20'
      }
    },
    {
      skill: {
        id: '6',
        name: 'Digital Marketing',
        category: 'Business',
        description: 'Learn SEO, social media marketing, Google Ads, and content marketing strategies for modern businesses.',
        level: 'Intermediate',
        tags: ['seo', 'social-media', 'marketing', 'google-ads']
      },
      user: {
        id: '6',
        name: 'Vikram Joshi',
        email: 'vikram@example.com',
        location: 'Chennai, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.5,
        completedSwaps: 28,
        joinedDate: '2024-01-08'
      }
    },
    {
      skill: {
        id: '7',
        name: 'Classical Dance (Bharatanatyam)',
        category: 'Arts',
        description: 'Traditional Indian classical dance form with focus on expressions, postures, and storytelling through dance.',
        level: 'Expert',
        tags: ['bharatanatyam', 'classical-dance', 'indian-culture', 'performance']
      },
      user: {
        id: '7',
        name: 'Meera Iyer',
        email: 'meera@example.com',
        location: 'Kochi, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.9,
        completedSwaps: 67,
        joinedDate: '2023-08-15'
      }
    },
    {
      skill: {
        id: '8',
        name: 'Yoga and Meditation',
        category: 'Health',
        description: 'Traditional yoga practices including asanas, pranayama, and meditation techniques for physical and mental wellness.',
        level: 'Advanced',
        tags: ['yoga', 'meditation', 'wellness', 'mindfulness']
      },
      user: {
        id: '8',
        name: 'Ravi Kumar',
        email: 'ravi@example.com',
        location: 'Rishikesh, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.8,
        completedSwaps: 89,
        joinedDate: '2023-06-12'
      }
    },
    {
      skill: {
        id: '9',
        name: 'Mobile App Development',
        category: 'Programming',
        description: 'Build native Android and iOS apps using React Native and Flutter frameworks.',
        level: 'Intermediate',
        tags: ['react-native', 'flutter', 'mobile', 'android', 'ios']
      },
      user: {
        id: '9',
        name: 'Sneha Agarwal',
        email: 'sneha@example.com',
        location: 'Gurgaon, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.7,
        completedSwaps: 34,
        joinedDate: '2024-02-20'
      }
    },
    {
      skill: {
        id: '10',
        name: 'Indian Cooking',
        category: 'Culinary',
        description: 'Learn authentic Indian recipes from different regions including spices, techniques, and traditional cooking methods.',
        level: 'Intermediate',
        tags: ['cooking', 'indian-cuisine', 'spices', 'traditional']
      },
      user: {
        id: '10',
        name: 'Deepika Nair',
        email: 'deepika@example.com',
        location: 'Thiruvananthapuram, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.6,
        completedSwaps: 21,
        joinedDate: '2024-03-10'
      }
    },
    {
      skill: {
        id: '11',
        name: 'Financial Planning',
        category: 'Business',
        description: 'Personal finance management, investment strategies, tax planning, and wealth building techniques.',
        level: 'Advanced',
        tags: ['finance', 'investment', 'planning', 'wealth']
      },
      user: {
        id: '11',
        name: 'Amit Verma',
        email: 'amit@example.com',
        location: 'Kolkata, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.8,
        completedSwaps: 45,
        joinedDate: '2023-10-05'
      }
    },
    {
      skill: {
        id: '12',
        name: 'Photography',
        category: 'Arts',
        description: 'Portrait, landscape, and street photography techniques using DSLR and mirrorless cameras.',
        level: 'Intermediate',
        tags: ['photography', 'dslr', 'portrait', 'landscape']
      },
      user: {
        id: '12',
        name: 'Ishaan Malhotra',
        email: 'ishaan@example.com',
        location: 'Jaipur, India',
        skillsOffered: [],
        skillsWanted: [],
        availability: [],
        isPublic: true,
        rating: 4.7,
        completedSwaps: 29,
        joinedDate: '2024-01-25'
      }
    }
  ];

  const categories = ['Programming', 'Design', 'Languages', 'Music', 'Business', 'Health', 'Sports'];
  const levels = ['Beginner', 'Intermediate', 'Advanced', 'Expert'];

  const filteredSkills = useMemo(() => {
    return mockSkills.filter(({ skill }) => {
      const matchesSearch = skill.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           skill.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           skill.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesCategory = !selectedCategory || skill.category === selectedCategory;
      const matchesLevel = !selectedLevel || skill.level === selectedLevel;

      return matchesSearch && matchesCategory && matchesLevel;
    });
  }, [searchTerm, selectedCategory, selectedLevel]);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Browse Skills</h1>
          <p className="text-gray-600">Discover amazing skills offered by our community members</p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8"
        >
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search skills, descriptions, or tags..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Category Filter */}
            <div className="lg:w-48">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">All Categories</option>
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
            </div>

            {/* Level Filter */}
            <div className="lg:w-48">
              <select
                value={selectedLevel}
                onChange={(e) => setSelectedLevel(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">All Levels</option>
                {levels.map(level => (
                  <option key={level} value={level}>{level}</option>
                ))}
              </select>
            </div>

            {/* View Mode */}
            <div className="flex bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === 'grid'
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Grid className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === 'list'
                    ? 'bg-white text-blue-600 shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Results */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <p className="text-gray-600">
            Showing {filteredSkills.length} skill{filteredSkills.length !== 1 ? 's' : ''}
          </p>
        </motion.div>

        {/* Skills Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className={
            viewMode === 'grid'
              ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6'
              : 'space-y-4'
          }
        >
          {filteredSkills.map(({ skill, user }, index) => (
            <motion.div
              key={skill.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * index }}
            >
              <SkillCard
                skill={skill}
                user={user}
                onSwapRequest={() => {
                  // Handle swap request
                  console.log('Swap request for:', skill.name);
                }}
                className={viewMode === 'list' ? 'max-w-none' : ''}
              />
            </motion.div>
          ))}
        </motion.div>

        {filteredSkills.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No skills found</h3>
            <p className="text-gray-600">
              Try adjusting your search criteria or browse all skills
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
};