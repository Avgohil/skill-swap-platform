import React from 'react';
import { Users, MessageCircle, Star, Shield, Globe, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

export const Features: React.FC = () => {
  const features = [
    {
      icon: Users,
      title: 'Smart Matching',
      description: 'Our AI-powered algorithm connects you with the perfect skill partners based on your interests, location, and availability.',
      color: 'from-blue-500 to-blue-600'
    },
    {
      icon: MessageCircle,
      title: 'Seamless Communication',
      description: 'Built-in messaging system makes it easy to coordinate lessons, share resources, and build lasting learning relationships.',
      color: 'from-green-500 to-green-600'
    },
    {
      icon: Star,
      title: 'Quality Assurance',
      description: 'Comprehensive rating and review system ensures high-quality exchanges and helps build trust within our community.',
      color: 'from-yellow-500 to-yellow-600'
    },
    {
      icon: Shield,
      title: 'Safe & Secure',
      description: 'Advanced verification processes and safety guidelines create a secure environment for all skill exchanges.',
      color: 'from-red-500 to-red-600'
    },
    {
      icon: Globe,
      title: 'Global Community',
      description: 'Connect with learners and teachers from around the world. Learn languages, cultures, and skills from diverse perspectives.',
      color: 'from-purple-500 to-purple-600'
    },
    {
      icon: Zap,
      title: 'Instant Connections',
      description: 'Find and connect with skill partners instantly. Start learning or teaching within minutes of joining our platform.',
      color: 'from-orange-500 to-orange-600'
    }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Why Choose SkillSwap?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover the features that make SkillSwap the premier platform for skill exchange and collaborative learning.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="group relative bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 border border-gray-100"
            >
              <div className={`inline-flex items-center justify-center w-12 h-12 rounded-lg bg-gradient-to-r ${feature.color} mb-6 group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              
              <h3 className="text-xl font-semibold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors">
                {feature.title}
              </h3>
              
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>

              {/* Hover Effect Border */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-600 to-purple-600 opacity-0 group-hover:opacity-5 transition-opacity duration-300" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};