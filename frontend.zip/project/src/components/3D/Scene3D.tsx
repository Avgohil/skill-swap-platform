import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment, PerspectiveCamera } from '@react-three/drei';
import { FloatingSkillOrb } from './FloatingSkillOrb';

interface Scene3DProps {
  skills?: Array<{ name: string; color: string }>;
  className?: string;
}

export const Scene3D: React.FC<Scene3DProps> = ({ skills = [], className = "" }) => {
  const defaultSkills = [
    { name: 'React', color: '#61DAFB' },
    { name: 'Design', color: '#FF6B6B' },
    { name: 'Marketing', color: '#4ECDC4' },
    { name: 'Music', color: '#45B7D1' },
    { name: 'Languages', color: '#96CEB4' },
    { name: 'Cooking', color: '#FFEAA7' }
  ];

  const displaySkills = skills.length > 0 ? skills : defaultSkills;

  return (
    <div className={`w-full h-full ${className}`}>
      <Canvas>
        <Suspense fallback={null}>
          <PerspectiveCamera makeDefault position={[0, 0, 8]} />
          <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
          <Environment preset="sunset" />
          
          <ambientLight intensity={0.4} />
          <pointLight position={[10, 10, 10]} intensity={1} />
          <pointLight position={[-10, -10, -10]} intensity={0.5} />

          {displaySkills.map((skill, index) => {
            const angle = (index / displaySkills.length) * Math.PI * 2;
            const radius = 3;
            const x = Math.cos(angle) * radius;
            const z = Math.sin(angle) * radius;
            const y = Math.sin(index * 0.5) * 1;
            
            return (
              <FloatingSkillOrb
                key={skill.name}
                position={[x, y, z]}
                color={skill.color}
                skillName={skill.name}
                size={0.8}
              />
            );
          })}
        </Suspense>
      </Canvas>
    </div>
  );
};