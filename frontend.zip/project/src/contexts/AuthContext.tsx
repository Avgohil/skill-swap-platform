import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, AuthContextType } from '../types';

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = async (email: string, password: string) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockUser: User = {
      id: '1',
      name: 'Priya Sharma',
      email,
      location: 'San Francisco, CA',
      bio: 'Passionate about learning and sharing knowledge',
      skillsOffered: [
        {
          id: '1',
          name: 'React Development',
          category: 'Programming',
          description: 'Frontend development with React and TypeScript',
          level: 'Advanced',
          tags: ['react', 'typescript', 'frontend']
        }
      ],
      skillsWanted: [
        {
          id: '2',
          name: 'UI/UX Design',
          category: 'Design',
          description: 'User interface and experience design',
          level: 'Beginner',
          tags: ['design', 'figma', 'ux']
        }
      ],
      availability: ['Monday', 'Wednesday', 'Friday'],
      isPublic: true,
      rating: 4.8,
      completedSwaps: 12,
      joinedDate: '2024-01-15',
      isAdmin: email === 'admin@skillswap.com'
    };

    setUser(mockUser);
    localStorage.setItem('user', JSON.stringify(mockUser));
  };

  const register = async (userData: Partial<User>) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newUser: User = {
      id: Date.now().toString(),
      name: userData.name || '',
      email: userData.email || '',
      location: userData.location,
      bio: userData.bio,
      skillsOffered: [],
      skillsWanted: [],
      availability: [],
      isPublic: true,
      rating: 0,
      completedSwaps: 0,
      joinedDate: new Date().toISOString().split('T')[0],
      isAdmin: false
    };

    setUser(newUser);
    localStorage.setItem('user', JSON.stringify(newUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const updateProfile = async (updates: Partial<User>) => {
    if (!user) return;
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const updatedUser = { ...user, ...updates };
    setUser(updatedUser);
    localStorage.setItem('user', JSON.stringify(updatedUser));
  };

  const value: AuthContextType = {
    user,
    login,
    register,
    logout,
    updateProfile
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};